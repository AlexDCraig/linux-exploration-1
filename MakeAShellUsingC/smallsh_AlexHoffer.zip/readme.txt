Instructions on how to compile:
- smallsh.c contains all code necessary
- compile using gcc smallsh.c -o smallsh before testing
- then run ./p3testscript 2>&1 (Note: I have to do ./ before the p3testscript on my bash otherwise it says
command not found... It may be different on yours, i.e. simply putting p3testscript 2>&1)
